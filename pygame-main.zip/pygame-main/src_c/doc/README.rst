These files are generated from the rst files in docs/reST/ref/

Both the .rst file and the generated .h file should be committed.

To generate docs run: python setup.py docs
